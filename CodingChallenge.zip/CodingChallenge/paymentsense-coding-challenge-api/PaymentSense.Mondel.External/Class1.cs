﻿using System;

namespace PaymentSense.Mondel.External
{
    public class Class1
    {
    }
}

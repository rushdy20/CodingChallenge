﻿
namespace PaymentSense.Models.External.Get.Response
{
  public  class GetCountriesResponse
    {
        public string CountryCallingCode { get; set; }
        public string Name { get; set; }
        public string Capital { get; set; }
    }
}

﻿
namespace PaymentSense.Models.Internal
{
    public class Country
    {
        public string CallingCodes { get; set; }
        public string Name { get; set; }
        public string Capital { get; set; }
        public string Region { get; set; }
    }
}

﻿using System;

namespace PaymentSense.Models.Internal
{
    public class Class1
    {
    }
}

﻿namespace PaymentSense.Models.ServicesClient
{
    public class RestCountry
    {
        public string CallingCode { get; set; }
        public string Name { get; set; }
        public string Capital { get; set; }
        public string Region { get; set; }
    }
}

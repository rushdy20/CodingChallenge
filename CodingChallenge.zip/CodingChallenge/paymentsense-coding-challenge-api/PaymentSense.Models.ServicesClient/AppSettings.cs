﻿namespace PaymentSense.Models.ServicesClient
{
    public class AppSettings
    {
        public string ServiceUrl { get; set; }

    }
}
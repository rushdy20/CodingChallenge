﻿using System;

namespace PaymentSense.BusinessLayer
{
    public class Class1
    {
    }
}
